export const firstUpperCase = (message) =>
  message[0].toUpperCase() + message.substring(1);
