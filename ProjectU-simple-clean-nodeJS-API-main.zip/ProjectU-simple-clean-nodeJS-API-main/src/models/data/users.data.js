// an array on objects, where the schema rules are defined in user.schemas.js
// { name, email, city, country }
const users = [];

export default users;
